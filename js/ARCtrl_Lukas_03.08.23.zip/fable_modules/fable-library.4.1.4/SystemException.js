import { Exception } from "./Types.js";
export class SystemException extends Exception {
}
export class TimeoutException extends SystemException {
}
